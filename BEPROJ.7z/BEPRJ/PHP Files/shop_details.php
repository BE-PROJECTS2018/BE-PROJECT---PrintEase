<?php
require "conf.php";

$wbppcost = $_POST["swbppcost"];
$wbbulkcost = $_POST["swbbulkcost"];
$colorppcost = $_POST["scolorppcost"];
$colorbulkcost = $_POST["scolorbulkcost"];
$A5pagecost = $_POST["sA5pagecost"];
$laminationcost = $_POST["slaminationcost"];

//$mysql_qry = "SELECT * FROM customer where c_name like '".$username."';";

//$result = mysqli_query($conn, $mysql_qry); 
$response = array();

	$mysql_qry = "INSERT INTO `shopdetails` (`s_id`,`BWCost`,`BWBCost`,`ColorCost`,`ColorBCost`,`A5Cost`,`LaminationCost`) VALUES (NULL,'$wbppcost', '$wbbulkcost', '$colorppcost', '$colorbulkcost', '$A5pagecost','$laminationcost');";
	$result = mysqli_query($conn, $mysql_qry);
	$code = "Deatils have been updated!!";
	$message = "Thank You for registering with PrintEase!! Now you can login and enjoy our service";

$response['code']=$code;
$response['message']=$message;
echo json_encode($response);
mysqli_close($conn);
?>