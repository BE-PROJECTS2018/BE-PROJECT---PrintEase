<?php
require "conf.php";

$username=$_POST["username"];
$password=$_POST["password"];
//$confirmpassword=$_POST["confirmpassword"];
$contactno=$_POST["contactno"];
$address=$_POST["address"];
$email=$_POST["email"];

$mysql_qry = "SELECT * FROM customer where c_name like '".$username."';";

$result = mysqli_query($conn, $mysql_qry); 
$response=array();

if(mysqli_num_rows($result) > 0)
{
	$code = "Registeration Failed";
	$message = "User already exists!! Please choose another username!!";
	//array_push($response, array("code"=>$code,"message"=>$message));
	//echo json_encode($response);
}
else
{
	$mysql_ins = "INSERT INTO `customer` (`c_id`,`c_password`,`c_address`,`c_name`,`c_phoneno`,`c_emailid`) VALUES (NULL,'$password', '$address', '$username', '$contactno', '$email');";
	$result = mysqli_query($conn, $mysql_ins);
	$code = "Registeration Successful";
	$message = "Thank You for registering with PrintEase!! Now you can login and enjoy our service";
	//array_push($response, array("code"=>$code,"message"=>$message));
	//echo json_encode($response);
}
$response['code']=$code;
$response['message']=$message;
echo json_encode($response);
mysqli_close($conn);

?>