<?php

$host = "localhost";
$db_user = "id5030156_groupno13";
$db_password = "PrintEase@12345";
$db_name = "id5030156_printease";

$conn = mysqli_connect($host, $db_user, $db_password, $db_name);
?>