<?php
require "conf.php";
$sid=$_POST["sb_sid"];
$size = $_POST["sb_size"];
$quantity = $_POST["sb_quantity"];
$price = $_POST["sb_price"];


$response = array();

	$mysql_qry = "UPDATE `sunboards` SET `size`='".$size."',`quantity`='".$quantity."',`price`='".$price."'
        where `s_id` = '".$sid."' ";
	$result = mysqli_query($conn, $mysql_qry);
	$code = "Deatils have been updated!!";
	$message = "Your details will be sent to shopkeeper shortly!!";

$response['code']=$code;
$response['message']=$message;
echo json_encode($response);
mysqli_close($conn);

?>