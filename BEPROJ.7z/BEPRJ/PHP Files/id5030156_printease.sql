-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 09, 2018 at 07:45 AM
-- Server version: 10.2.12-MariaDB
-- PHP Version: 7.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id5030156_printease`
--

-- --------------------------------------------------------

--
-- Table structure for table `avails`
--

CREATE TABLE `avails` (
  `p_id` int(50) NOT NULL,
  `c_id` int(50) DEFAULT NULL,
  `st_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `bal_no_of_copies` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blackandwhite`
--

CREATE TABLE `blackandwhite` (
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `s_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `colourprint`
--

CREATE TABLE `colourprint` (
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `s_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `createjob`
--

CREATE TABLE `createjob` (
  `cj_id` int(11) NOT NULL,
  `c_id` int(11) DEFAULT NULL,
  `job_name` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `doc_link` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `sides` int(11) DEFAULT NULL,
  `pages` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `total_no_of_copies` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(11) NOT NULL,
  `c_password` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `c_address` varchar(11) CHARACTER SET latin1 DEFAULT NULL,
  `c_name` varchar(20) CHARACTER SET latin1 NOT NULL,
  `c_phoneno` bigint(10) NOT NULL,
  `c_emailid` varchar(30) CHARACTER SET latin1 NOT NULL,
  `c_dob` date DEFAULT NULL,
  `rating` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `c_password`, `c_address`, `c_name`, `c_phoneno`, `c_emailid`, `c_dob`, `rating`) VALUES
(1, 'abc', NULL, 'printease', 7773959641, 'dinesh@abc', NULL, NULL),
(4, 'suren', 'abc', 'suren', 7773959641, 'abc', NULL, NULL),
(5, '123', '123abc', 'jay', 1234567890, 'abc@abc', NULL, NULL),
(6, '123', 'abc', 'jaymn', 1234567890, 'abc@abc', NULL, NULL),
(7, '123', 'abc', 'Simran', 1234578096, 'a@g.c', NULL, NULL),
(8, 'suren', 'abc', 'suren123', 123456789, 'abc@abc.com', NULL, NULL),
(9, '12345', 'abc', 'piyush', 1234567890, 'piyush.gidwani@ves', NULL, NULL),
(10, 'piyush1', 'ulhas', 'piyush1', 8180007601, 'piyush.gidwani@ves', NULL, NULL),
(11, '123', 'ABC\n', 'deepika', 1234567890, 'abc@abc.com', NULL, NULL),
(12, '123', '\nchembur\n', 'deepika27', 9833300761, 'deep@gmail.com', NULL, NULL),
(13, 'ab', 'baba', 'ab', 12472580369, 'nM', NULL, NULL),
(14, 'abc', 'abc', 'harshada', 1234567890, 'abc@abc.com', NULL, NULL),
(15, 'sample', 'bsnanN', 'sample', 1472536890, 'vzbzM', NULL, NULL),
(16, 'sample', 'bsnanN', 'sample1', 1472536890, 'vzbzM', NULL, NULL),
(17, 'sample', 'bsnanN', 'project', 1472536890, 'vzbzM', NULL, NULL),
(18, 'abc123', 'abc', 'abc123', 1236548790, 'abc', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Doc`
--

CREATE TABLE `Doc` (
  `id` int(11) NOT NULL,
  `url` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `envelope`
--

CREATE TABLE `envelope` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobdetails`
--

CREATE TABLE `jobdetails` (
  `cj_id` int(11) NOT NULL,
  `doc_link` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `disc_amt` int(50) DEFAULT NULL,
  `amount` int(50) DEFAULT NULL,
  `pt_id` int(50) DEFAULT NULL,
  `pm_id` int(50) DEFAULT NULL,
  `ps_id` int(50) DEFAULT NULL,
  `no_of_copies` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `keychain`
--

CREATE TABLE `keychain` (
  `kc_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `letterheads`
--

CREATE TABLE `letterheads` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `magneticclips`
--

CREATE TABLE `magneticclips` (
  `mc_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `magneticsigns`
--

CREATE TABLE `magneticsigns` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mousepad`
--

CREATE TABLE `mousepad` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nametag`
--

CREATE TABLE `nametag` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `p_id` int(11) NOT NULL,
  `p_amount` int(11) DEFAULT NULL,
  `p_duration` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `p_description` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `p_name` char(50) CHARACTER SET latin1 DEFAULT NULL,
  `pt_id` int(11) DEFAULT NULL,
  `ps_id` int(11) DEFAULT NULL,
  `pm_id` int(11) DEFAULT NULL,
  `no_of_copies` int(11) DEFAULT NULL,
  `disc_perc` int(11) DEFAULT NULL,
  `region` char(50) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `p_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `p_amount` int(11) NOT NULL,
  `p_mode` text CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posters`
--

CREATE TABLE `posters` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shopdetails`
--

CREATE TABLE `shopdetails` (
  `BWCost` int(11) DEFAULT NULL,
  `BWBCost` int(11) DEFAULT NULL,
  `ColorCost` int(11) DEFAULT NULL,
  `ColorBCost` int(11) DEFAULT NULL,
  `A5Cost` int(11) DEFAULT NULL,
  `LaminationCost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shopkeeper`
--

CREATE TABLE `shopkeeper` (
  `s_id` int(11) NOT NULL,
  `s_name` varchar(20) CHARACTER SET latin1 NOT NULL,
  `s_password` varchar(50) CHARACTER SET latin1 NOT NULL,
  `s_address` text CHARACTER SET latin1 DEFAULT NULL,
  `s_phoneno` bigint(20) DEFAULT NULL,
  `s_emailid` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `s_status` char(10) CHARACTER SET latin1 DEFAULT NULL,
  `s_description` text CHARACTER SET latin1 DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `est_time` time DEFAULT NULL,
  `latitude` text COLLATE utf8_unicode_ci NOT NULL,
  `longitude` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `shopkeeper`
--

INSERT INTO `shopkeeper` (`s_id`, `s_name`, `s_password`, `s_address`, `s_phoneno`, `s_emailid`, `s_status`, `s_description`, `rating`, `est_time`, `latitude`, `longitude`) VALUES
(4, 'sagar', 'sagar', 'abc', 9960619967, 'sagar@ves.ac.in', NULL, NULL, NULL, NULL, '', ''),
(5, 'suren', '123', 'abc', 9960619967, 'abc@abc.com', NULL, NULL, NULL, NULL, '', ''),
(6, 'abcd', 'abcd', 'abcd', 8793385422, 'avsd@hdg.gh', NULL, NULL, NULL, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `signboards`
--

CREATE TABLE `signboards` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sunboards`
--

CREATE TABLE `sunboards` (
  `s_id` int(50) NOT NULL,
  `size` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_customer`
--

CREATE TABLE `transaction_customer` (
  `t_id` int(50) NOT NULL,
  `c_id` int(50) NOT NULL,
  `date_of_transaction` date DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `mode_of_payment` text CHARACTER SET latin1 DEFAULT NULL,
  `time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_shopkeeper`
--

CREATE TABLE `transaction_shopkeeper` (
  `t_idshopkeeper` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `mode_of_payment` text CHARACTER SET latin1 DEFAULT NULL,
  `time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `usbdrive`
--

CREATE TABLE `usbdrive` (
  `ud_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `visiting`
--

CREATE TABLE `visiting` (
  `vc_id` int(11) NOT NULL,
  `s_id` int(11) DEFAULT NULL,
  `thickness` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `visiting`
--

INSERT INTO `visiting` (`vc_id`, `s_id`, `thickness`, `quantity`, `price`) VALUES
(1, 4, 50, 200, 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `avails`
--
ALTER TABLE `avails`
  ADD KEY `c_id` (`c_id`) USING BTREE,
  ADD KEY `p_id` (`p_id`) USING BTREE;

--
-- Indexes for table `blackandwhite`
--
ALTER TABLE `blackandwhite`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `colourprint`
--
ALTER TABLE `colourprint`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `createjob`
--
ALTER TABLE `createjob`
  ADD UNIQUE KEY `cj_id` (`cj_id`),
  ADD KEY `c_id` (`c_id`) USING BTREE;

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `envelope`
--
ALTER TABLE `envelope`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `jobdetails`
--
ALTER TABLE `jobdetails`
  ADD PRIMARY KEY (`cj_id`) USING BTREE,
  ADD KEY `pm_id` (`pm_id`),
  ADD KEY `ps_id` (`ps_id`),
  ADD KEY `pt_id` (`pt_id`);

--
-- Indexes for table `keychain`
--
ALTER TABLE `keychain`
  ADD PRIMARY KEY (`kc_id`),
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `letterheads`
--
ALTER TABLE `letterheads`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `magneticclips`
--
ALTER TABLE `magneticclips`
  ADD PRIMARY KEY (`mc_id`),
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `magneticsigns`
--
ALTER TABLE `magneticsigns`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `mousepad`
--
ALTER TABLE `mousepad`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `nametag`
--
ALTER TABLE `nametag`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `pm_id` (`pm_id`) USING BTREE,
  ADD KEY `ps_id` (`ps_id`) USING BTREE,
  ADD KEY `pt_id` (`pt_id`) USING BTREE;

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD KEY `c_id` (`c_id`) USING BTREE;

--
-- Indexes for table `posters`
--
ALTER TABLE `posters`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `shopkeeper`
--
ALTER TABLE `shopkeeper`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `signboards`
--
ALTER TABLE `signboards`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `sunboards`
--
ALTER TABLE `sunboards`
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `transaction_customer`
--
ALTER TABLE `transaction_customer`
  ADD PRIMARY KEY (`t_id`),
  ADD UNIQUE KEY `c_id` (`c_id`) USING BTREE;

--
-- Indexes for table `transaction_shopkeeper`
--
ALTER TABLE `transaction_shopkeeper`
  ADD PRIMARY KEY (`t_idshopkeeper`),
  ADD KEY `c_id` (`c_id`) USING BTREE;

--
-- Indexes for table `usbdrive`
--
ALTER TABLE `usbdrive`
  ADD PRIMARY KEY (`ud_id`),
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `visiting`
--
ALTER TABLE `visiting`
  ADD PRIMARY KEY (`vc_id`),
  ADD KEY `s_id` (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `jobdetails`
--
ALTER TABLE `jobdetails`
  MODIFY `cj_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `keychain`
--
ALTER TABLE `keychain`
  MODIFY `kc_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `magneticclips`
--
ALTER TABLE `magneticclips`
  MODIFY `mc_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shopkeeper`
--
ALTER TABLE `shopkeeper`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usbdrive`
--
ALTER TABLE `usbdrive`
  MODIFY `ud_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blackandwhite`
--
ALTER TABLE `blackandwhite`
  ADD CONSTRAINT `blackandwhite_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `shopkeeper` (`s_id`);

--
-- Constraints for table `colourprint`
--
ALTER TABLE `colourprint`
  ADD CONSTRAINT `colourprint_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `shopkeeper` (`s_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
