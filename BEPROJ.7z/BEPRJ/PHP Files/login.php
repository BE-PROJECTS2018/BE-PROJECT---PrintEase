<?php
require "conf.php";
$Uusername=$_POST["username"];
$Password=$_POST["password"];
$response= array();
$mysql_qry="SELECT * FROM customer where c_name like '".$Uusername."' and c_password like '".$Password."';";
$result = mysqli_query($conn, $mysql_qry);
$result1 = mysqli_fetch_assoc($result);
$value = "null";
if(mysqli_num_rows($result) > 0)
{
    $code = "Login Successfull";
    $value = $result1["c_id"];
}
else
{
    $code = "Login  NOT Successfull";
}
$response['code'] = $code;
$response['value']=$value;
echo json_encode($response);
mysqli_close($conn);
?>