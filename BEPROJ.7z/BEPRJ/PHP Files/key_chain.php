<?php
require "conf.php";
$sid=$_POST["kc_sid"];
$size = $_POST["kc_size"];
$quantity = $_POST["kc_quantity"];
$price = $_POST["kc_price"];


$response = array();

	$mysql_qry = "UPDATE `keychain` SET `size`='".$size."',`quantity`='".$quantity."',`price`='".$price."'
        where `s_id` = '".$sid."' ";
	$result = mysqli_query($conn, $mysql_qry);
	$code = "Deatils have been updated!!";
	$message = "Your details will be sent to shopkeeper shortly!!";

$response['code']=$code;
$response['message']=$message;
echo json_encode($response);
mysqli_close($conn);

?>