<?php
require "conf.php";
$Uusername=$_POST["username"];
$Password=$_POST["password"];
$response= array();
$mysql_qry="SELECT * FROM shopkeeper where s_name like '".$Uusername."' and s_password like '".$Password."';";
$result = mysqli_query($conn, $mysql_qry);
$value = "null";
if(mysqli_num_rows($result) > 0)
{
    $row=mysqli_fetch_assoc($result);
    $code = "Login Successfull";
    $value = $row["s_id"];
}
else
{
    $code = "Login  NOT Successfull";
}
$response['code'] = $code;
$response['value'] = $value;
echo json_encode($response);
mysqli_close($conn);
?>