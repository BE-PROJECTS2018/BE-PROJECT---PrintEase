<?php
require "conf.php";

$username=$_POST["username"];
$password=$_POST["password"];
//$confirmpassword=$_POST["confirmpassword"];
$contactno=$_POST["contactno"];
$address=$_POST["address"];
$email=$_POST["email"];

$mysql_qry = "SELECT * FROM shopkeeper where s_name like '".$username."';";

$result = mysqli_query($conn, $mysql_qry); 
$response=array();

if(mysqli_num_rows($result) > 0)
{
	$code = "Registeration Failed";
	$message = "Username already exists!! Please choose another username!!";
	//array_push($response, array("code"=>$code,"message"=>$message));
	//echo json_encode($response);
}
else
{
	$mysql_ins = "INSERT INTO `shopkeeper` (`s_id`,`s_name`,`s_password`,`s_address`,`s_phoneno`,`s_emailid`) VALUES (NULL,'$username','$password', '$address', '$contactno', '$email');";
	$result = mysqli_query($conn, $mysql_ins);
	$code = "Registeration Successful";
	$message = "Thank You for registering with PrintEase!! Now you can login and enjoy our service";
	//array_push($response, array("code"=>$code,"message"=>$message));
	//echo json_encode($response);
}
$response['code']=$code;
$response['message']=$message;
echo json_encode($response);
mysqli_close($conn);

?>