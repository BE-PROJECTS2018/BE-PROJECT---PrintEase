package com.simran.printease;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DocDetails extends AppCompatActivity {

    Spinner spinnertype,spinnersize,spinnermaterial;
    EditText etCopies, etpages;
    CheckBox twosides, lamination;
    RadioButton radiobuttonall, radiobuttonpages;
    Button sbtnPrint;

    String s_spinnertype, s_spinnersize, s_spinnermaterial, s_etCopies, s_etpages, s_twosides, s_lamination, s_radiobuttonall, s_radiobuttonpages;

    AlertDialog.Builder builder;
    private final static String Server_url = "https://printease.000webhostapp.com/doc_details.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_details);

        spinnertype=(Spinner)findViewById(R.id.spinnertype);
        spinnersize=(Spinner)findViewById(R.id.spinnersize);
        spinnermaterial=(Spinner)findViewById(R.id.spinnermaterial);
        etCopies=(EditText)findViewById(R.id.etCopies);
        etpages=(EditText)findViewById(R.id.etpages);
        twosides=(CheckBox)findViewById(R.id.twosides);
        lamination=(CheckBox)findViewById(R.id.lamination);
        radiobuttonall=(RadioButton)findViewById(R.id.radiobuttonall);
        radiobuttonpages=(RadioButton)findViewById(R.id.radiobuttonpages);
        sbtnPrint= (Button) findViewById(R.id.sbtnPrint);

        builder = new AlertDialog.Builder(DocDetails.this);

        ArrayList<String> optiontype = new ArrayList<String>();
        optiontype.add("Black and White");
        optiontype.add("Color");

        ArrayAdapter<String> typeadapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, optiontype);
        spinnertype.setAdapter(typeadapter);

        ArrayList<String> optionsize = new ArrayList<String>();
        optionsize.add("A4");
        optionsize.add("A5");

        ArrayAdapter<String> sizeadapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, optionsize);
        spinnersize.setAdapter(sizeadapter);


        ArrayList<String> optionmaterial = new ArrayList<String>();
        optionmaterial.add("Normal");
        optionmaterial.add("Certificate Page");

        ArrayAdapter<String> materialdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, optionmaterial);
        spinnermaterial.setAdapter(materialdapter);

        sbtnPrint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 Intent intent = new Intent(DocDetails.this, PreviewActivity.class);
                 startActivity(intent);
//                s_spinnertype = spinnertype.getText().toString();
//                s_spinnersize = spinnersize.getText().toString();
//                s_spinnermaterial = spinnermaterial.getText().toString();
//                s_etCopies = etCopies.getText().toString();
//                s_etpages = etpages.getText().toString();
//                s_twosides = twosides.getText().toString();
//                 s_lamination = lamination.getText().toString();
//                 s_radiobuttonall = radiobuttonall.getText().toString();
//                s_radiobuttonpages = radiobuttonpages.getText().toSTring();
                makejsonobject();
            }
        });
    }

  public void makejsonobject(){
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest strRequest = new StringRequest(Request.Method.POST, Server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null;
                        try {
                            Toast.makeText(DocDetails.this, response, Toast.LENGTH_SHORT).show();
                            jsonObject = new JSONObject(response);
                            String serverResponseCode=jsonObject.getString("code");
                            String serverResponseMessage=jsonObject.getString("message");
                            builder.setTitle("Server Response");
                            builder.setMessage(serverResponseMessage);
                            displayAlert("code");
                        } catch (JSONException e1) {
                            e1.printStackTrace();
                        }
                        // Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("s_spinnertype",s_spinnertype);
                params.put("s_spinnersize",s_spinnersize);
                params.put("s_spinnermaterial",s_spinnermaterial);
                params.put("s_etCopies",s_etCopies);
                params.put("s_etpages",s_etpages);
                params.put("s_twosides",s_twosides);
                params.put("s_lamination",s_lamination);
                params.put("s_radiobuttonall",s_radiobuttonall);
                params.put("s_radiobuttonpages",s_radiobuttonpages);
                return params;
            }
        };
        queue.add(strRequest);
    }

    public void displayAlert(final String code)
    {
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                if(code.equals("Deatils have been updated!!"))
                {
                    Toast.makeText(DocDetails.this,"Details Updated", Toast.LENGTH_LONG).show();
                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    // SharedPreferences sharedPref = getSharedPreferences("sample",MODE_PRIVATE);
    // int highScore = sharedPref.getInt("c_id",0);

    // priavte classs sendData  AsyncTask<Void,Void,Void>

}