package com.simran.printease;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;


public class ShopDirections extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_directions);

        Intent i = getIntent();
        Bundle b = i.getExtras();
        String s_lat = (String) b.get("lat");
        String s_long = (String) b.get("long");
String sname = (String) b.get("sname");
        Uri gmmIntentUri = Uri.parse("geo:"+s_lat+","+s_long+"0?q="+sname);
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);

            }
        }
