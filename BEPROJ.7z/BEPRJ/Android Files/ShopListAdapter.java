package com.simran.printease;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by kunal on 2/5/2018.
 */

public class ShopListAdapter extends BaseAdapter {

    private Context mContext;
    private List<shopclass> mShopList;

    public ShopListAdapter(Context mContext, List<shopclass> mShopList) {
        this.mContext = mContext;
        this.mShopList = mShopList;
    }

    @Override
    public int getCount() {
        return mShopList.size();
    }

    @Override
    public Object getItem(int position) {
        return mShopList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(mContext, R.layout.shop, null);
        TextView tv_name = (TextView)v.findViewById(R.id.tvName);
        TextView tv_address = (TextView)v.findViewById(R.id.tvAddress);
        TextView tv_mindist = (TextView)v.findViewById(R.id.tvMinDist);

        tv_name.setText(mShopList.get(position).getName());
        tv_address.setText(mShopList.get(position).getAddress());
        tv_mindist.setText(String.valueOf(mShopList.get(position).getMindist()));

        v.setTag(mShopList.get(position).getId());
        return v;
    }
}

