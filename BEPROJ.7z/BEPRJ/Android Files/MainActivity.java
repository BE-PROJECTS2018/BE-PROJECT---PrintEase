package com.simran.printease;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.Request;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    Button cbtnLogin, cbtnSignup;
    CheckBox cchkShowpassword;
    private Context context;
    EditText cetUsername, cetPassword;
    private final static String Server_url = "https://printease.000webhostapp.com/login.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      /*  context = getApplicationContext();

        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.shared_pred_key), Context.MODE_PRIVATE); */

        cbtnLogin = (Button) findViewById(R.id.cbtnLogin);
        cbtnSignup = (Button) findViewById(R.id.cbtnSignup);
        cchkShowpassword = (CheckBox) findViewById(R.id.cchkShowpassword);
        cetUsername = (EditText) findViewById(R.id.cetUsername);
        cetPassword = (EditText) findViewById(R.id.cetPassword);
        final String type = "login";


        cbtnSignup.setOnClickListener(new View.OnClickListener()
                                      {
                                          @Override
                                          public void onClick(View v)
                                          {
                                              Intent intent = new Intent(getApplicationContext(), Signup.class);
                                              startActivity(intent);
                                          }
                                      }
        );

        cchkShowpassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (!isChecked)
                {
                    cetPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                else
                {
                    cetPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });

    }

    public void btnLoginCLick(View v) {
        makeJsonObject();
    }

    public void makeJsonObject() {
        final String inputusername = cetUsername.getText().toString();
        final String inputpassword = cetPassword.getText().toString();
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest strRequest = new StringRequest(Request.Method.POST, Server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("suru",response.toString());
                            JSONObject jsonObject = new JSONObject(response);
                          // Log.d("sur",jsonObject.toString());
                            String serverResponse=jsonObject.getString("code");
                          //  int c_id = jsonObject.getInt("value");

                            /**
                             * saving to local file system
                             */
                          //  SharedPreferences sharedPref = getSharedPreferences("sample",MODE_PRIVATE);

                           // SharedPreferences.Editor editor = sharedPref.edit();
                           // editor.putInt(getString(R.string.web_id), c_id);
                           // editor.commit();
                            //end of saving

                            if(serverResponse.equals("Login Successfull")){
                                Intent intent = new Intent(MainActivity.this, ServicesList.class);
                                startActivity(intent);
                                Toast.makeText(MainActivity.this, serverResponse, Toast.LENGTH_SHORT).show();
                                Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();

                            }else{
                                Toast.makeText(MainActivity.this, "Fail", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        // Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", inputusername);
                params.put("password", inputpassword);
                return params;
            }
        };
        queue.add(strRequest);
    }
}
