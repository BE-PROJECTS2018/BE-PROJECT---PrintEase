package com.simran.printease;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.Request;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.jar.Attributes;

import static java.util.jar.Attributes.*;


public class Signup extends AppCompatActivity
{

    Button cbtnRegister;
    EditText cetName, cetPasswords, cetConfirmpassword, cetNumber, cetAddress, cetEmail;
    String name, password, confirmpassword, contactno, address, email;
    AlertDialog.Builder builder;
    private final static String Server_url = "https://printease.000webhostapp.com/register.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        cbtnRegister = (Button)findViewById(R.id.cbtnRegister);
        cetName = (EditText)findViewById(R.id.cetName);
        cetPasswords = (EditText)findViewById(R.id.cetPasswords);
        cetConfirmpassword = (EditText)findViewById(R.id.cetConfirmpassword);
        cetNumber = (EditText)findViewById(R.id.cetNumber);
        cetAddress = (EditText)findViewById(R.id.cetAddress);
        cetEmail = (EditText)findViewById(R.id.cetEmail);

        builder = new AlertDialog.Builder(Signup.this);
        cbtnRegister.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                name = cetName.getText().toString();
                password = cetPasswords.getText().toString();
                confirmpassword = cetConfirmpassword.getText().toString();
                contactno = cetNumber.getText().toString();
                address = cetAddress.getText().toString();
                email = cetEmail.getText().toString();

                if(name.equals("")||password.equals("")||confirmpassword.equals("")||contactno.equals("")||address.equals("")||email.equals(""))
                {
                    builder.setTitle("Something went wrong!!");
                    builder.setMessage("Please fill all the fields!!");
                    displayAlert("input_error");
                }
                else
                {
                    if (!(password.equals(confirmpassword)))
                    {
                        builder.setTitle("Something went wrong!!");
                        builder.setMessage("Please make sure that your passwords are matching!!");
                        displayAlert("input_error");
                    }
                    else
                    {
                        makejsonobject();
                    }
                }
            }
        });

        // cbtnRegister.setOnClickListener(new View.OnClickListener() {
           // @Override
         //   public void onClick(View v) {
           //     Intent intent=new Intent(getApplicationContext(), ListOfShops.class);
            //    startActivity(intent);
           // }
    }

    public void makejsonobject(){
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest strRequest = new StringRequest(Request.Method.POST, Server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null;
                            try {
                                Toast.makeText(Signup.this, response, Toast.LENGTH_SHORT).show();
                                jsonObject = new JSONObject(response);
                                String serverResponseCode=jsonObject.getString("code");
                                String serverResponseMessage=jsonObject.getString("message");
                                builder.setTitle("Server Response");
                                builder.setMessage(serverResponseMessage);
                                // displayAlert(code);

                            } catch (JSONException e1) {
                                e1.printStackTrace();
                            }

                        // Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username",name);
                params.put("password",password);
                //  params.put("confirmpassword",confirmpassword);
                params.put("contactno",contactno);
                params.put("address",address);
                params.put("email",email);
                return params;
            }
        };

        queue.add(strRequest);

    }

    public void displayAlert(final String code)
    {
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                if(code.equals("input_error"))
                {
                    cetPasswords.setText("");
                    cetConfirmpassword.setText("");
                }
                else if(code.equals("Registeration Successful"))
                {
                    Intent intent = new Intent(Signup.this, MainActivity.class);
                    startActivity(intent);
                }
                else if(code.equals("Registeration Failed"))
                {
                    // Intent intent = new Intent(Signup.this, MainActivity.class);
                    // startActivity(intent);
                    cetName.setText("");
                    cetPasswords.setText("");
                    cetConfirmpassword.setText("");
                    cetNumber.setText("");
                    cetAddress.setText("");
                    cetEmail.setText("");
                    // cetConfirmpassword.setText("");
                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
