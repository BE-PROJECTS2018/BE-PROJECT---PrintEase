package com.simran.printease;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;



public class Rating extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        ShowDialog();
    }

    public void ShowDialog() {
        final AlertDialog.Builder popDialog = new AlertDialog.Builder(this);

        //rating.setMax(5);

        popDialog.setIcon(android.R.drawable.btn_star_big_on);
        popDialog.setTitle("Please rate!! ");


        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);


        // Add a TextView here for the "Title" label, as noted in the comments

        final RatingBar rates = new RatingBar(this);
        layout.addView(rates); // Another add method


        // Add another TextView here for the "Description" label
        final EditText description = new EditText(this);
        description.setHint("Write Review");
        layout.addView(description); // Notice this is an add method


        popDialog.setView(layout); // Again this is a set method, not add  //@Override


        // Button OK
        popDialog.setPositiveButton(android.R.string.ok,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }

                });

        popDialog.create();
        popDialog.show();
    }

}



