package com.simran.printease;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShopDetails extends AppCompatActivity {

    FloatingActionButton fabcreatejob2;
    Button cbtnDirections;
    String lat, longs;
    String s_name, s_addess, s_id;
    Double PerProductCost;
    Button cbtnCalc;
    private final static String Server_url = "https://printease.000webhostapp.com/cate_data_list.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_details);
        makeJsonObject();
        Intent i = getIntent();
        Bundle b = i.getExtras();
        s_id = (String) b.get("s_Id");
        s_addess = (String) b.get("s_address");
        s_name = (String) b.get("s_Name");
        lat = (String) b.get("lat");
        longs = (String) b.get("long");

//
//        Toast.makeText(this,name+"this",Toast.LENGTH_LONG).show();

        TextView name = (TextView) findViewById(R.id.tvshopname);
        name.setText(s_name);

        TextView address = (TextView) findViewById(R.id.tvshopaddress);
        address.setText(s_addess);



        //fabcreatejob2 = (FloatingActionButton) findViewById(R.id.fabcreatejob2);
        cbtnDirections = (Button) findViewById(R.id.cbtnDirections);
        cbtnCalc = (Button) findViewById(R.id.button2);
//        fabcreatejob2.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                Intent intent = new Intent(getApplicationContext(), UploadDetails.class);
//
//                startActivity(intent);
//            }
//        });


        cbtnDirections.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), ShopDirections.class);
                intent.putExtra("lat", lat);
                intent.putExtra("long", longs);
                intent.putExtra("sname", s_addess);
                startActivity(intent);

            }
        });

        cbtnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String t_p = String.valueOf(PerProductCost);
                EditText ed = (EditText) findViewById(R.id.editText5);
                Double totalPrice = Double.parseDouble(ed.getText().toString()) *  PerProductCost;
                Toast.makeText(ShopDetails.this,totalPrice.toString(),Toast.LENGTH_LONG).show();
//                TextView tv = (TextView) findViewById(R.id.textView39);
//                tv.setText("Price:" + totalPrice +"Rupees");
//

                Intent intent = new Intent(getApplicationContext(), UploadDetails.class);
                Spinner s = (Spinner) findViewById(R.id.spinner2);
                Toast.makeText(ShopDetails.this,s.getSelectedItem().toString(),Toast.LENGTH_LONG).show();
                intent.putExtra("Size",s.getSelectedItem().toString());
                intent.putExtra("Qty",ed.getText().toString());
                intent.putExtra("PerPageCost",PerProductCost.toString());
                intent.putExtra("Total",totalPrice.toString());
                startActivity(intent);





            }
        });


    }




    public void makeJsonObject() {
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest strRequest = new StringRequest(Request.Method.POST, Server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(ListOfShops.this,response,Toast.LENGTH_LONG).show();
                            Log.d("suru",response.toString());
                            //JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonarray = new JSONArray(response);

                            Spinner s = (Spinner) findViewById(R.id.spinner2);

                            ArrayAdapter<String> adapter;
                            List<String> list;

                            list = new ArrayList<String>();

                            for (int i = 0; i < jsonarray.length(); i++) {
                                JSONObject jsonobject = jsonarray.getJSONObject(i);
                                int s_id = jsonobject.getInt("s_id");
                                String s_name = jsonobject.getString("size");
                                String s_qty = jsonobject.getString("quantity");
                                String price = jsonobject.getString("price");
                                Toast.makeText(ShopDetails.this,s_name,Toast.LENGTH_LONG).show();
                                list.add(s_name);
                                PerProductCost =  Double.parseDouble(price)/Double.parseDouble(price);

//        list.add("Item 3");
//        list.add("Item 4");
//        list.add("Item 5");
//        list.add(s_id+"abc");



                            }
                            adapter = new ArrayAdapter<String>(getApplicationContext(),
                                    android.R.layout.simple_spinner_item, list);
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            s.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        // Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("s_id",s_id);
                return params;
            }
        };
        queue.add(strRequest);
    }

}
