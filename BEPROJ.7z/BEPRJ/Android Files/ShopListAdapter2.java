package com.simran.printease;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.List;


/**
 * Created by kunal on 3/9/2018.
 */


    public class ShopListAdapter2 extends BaseAdapter {

        private Context mContext;
        private List<shopclass> mShopList2;

        public ShopListAdapter2(Context mContext, List<shopclass> mShopList2) {
            this.mContext = mContext;
            this.mShopList2 = mShopList2;
        }

        @Override
        public int getCount() {
            return mShopList2.size();
        }

        @Override
        public Object getItem(int position) {
            return mShopList2.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = View.inflate(mContext, R.layout.shop2, null);
            TextView tv_name = (TextView)v.findViewById(R.id.tvName2);
            TextView tv_address = (TextView)v.findViewById(R.id.tvAddress2);
            TextView tv_mindist = (TextView)v.findViewById(R.id.tvMinDist2);

            tv_name.setText(mShopList2.get(position).getName());
            tv_address.setText(mShopList2.get(position).getAddress());
            tv_mindist.setText(String.valueOf(mShopList2.get(position).getMindist()));

            v.setTag(mShopList2.get(position).getId());
            return v;
        }
    }


