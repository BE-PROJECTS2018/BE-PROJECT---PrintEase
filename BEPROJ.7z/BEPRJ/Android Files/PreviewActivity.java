package com.simran.printease;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class PreviewActivity extends AppCompatActivity {

    Button cbtnConfirm, cbtnCancel;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);



        String[] docArray = {"Doc1 -  50Rs","Doc2 - 100Rs", "Total Cost - 150Rs"};

                ArrayAdapter adapter = new ArrayAdapter<String>(this,
                        R.layout.activity_listview, docArray);

                ListView listView = (ListView) findViewById(R.id.doclist);
                listView.setAdapter(adapter);


        cbtnConfirm= (Button) findViewById(R.id.cbtnConfirm);

        cbtnCancel= (Button) findViewById(R.id.cbtnCancel);

        cbtnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AlertDialog.Builder builder = new AlertDialog.Builder(PreviewActivity.this);
                builder.setMessage("Confirm Order ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent intent=new Intent(getApplicationContext(), DrawerActivity.class);
                                startActivity(intent);

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });

                AlertDialog alert = builder.create();

                alert.setTitle("Confirm");
                alert.show();

                     }
        });


        cbtnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(PreviewActivity.this);
                builder.setMessage("Cancel Order ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent intent=new Intent(getApplicationContext(), ListOfShops.class);
                                startActivity(intent);

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.cancel();

                            }
                        });

                AlertDialog alert = builder.create();

                alert.setTitle("Cancel");
                alert.show();

                     }
        });

    }
        }

