package com.simran.printease;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


public class ServicesList extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services_list);

        final String[] docArray = {"banners","Black and White","Colour","Envelope","Key Chain","LetterHeads","Magnetic Clips","Magnetic Signs","Mouse Pad","Name Tag","Posters","Sign Boards","Sun Boards","USB Flash Drives","Visiting Cards"};

        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.activity_list_display, docArray);

        ListView listView = (ListView) findViewById(R.id.doclist);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                /*
                Object o = prestListView.getItemAtPosition(position);
                prestationEco str = (prestationEco)o; //As you are using Default String Adapter
                Toast.makeText(getBaseContext(),str.getTitle(),Toast.LENGTH_SHORT).show();
                */
                Intent in = new Intent(ServicesList.this,ListOfShops.class);
                in.putExtra("selectedService",docArray[position]);
                int sid = (int) id;
//                Toast.makeText(ServicesList.this,docArray[sid],Toast.LENGTH_LONG).show();
                startActivity(in);
            }
        });
    }
}