package com.simran.printease;

/**
 * Created by kunal on 3/10/2018.
 */

public class PrinteaseConstants {
    public static String Server_Response;

}
