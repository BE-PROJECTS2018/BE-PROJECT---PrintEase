package com.simran.printease;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;



public class ListOfShops2 extends AppCompatActivity {

    private ListView lvShops2;
    private ShopListAdapter adapter2;
    private List<shopclass> mShopList2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_shops2);


                lvShops2 = (ListView) findViewById(R.id.lvShops2);
                mShopList2 = new ArrayList<>();

                mShopList2.add(new shopclass(1, "Royal Print House", "21-22, Navketan Building, Central Avenue Road, Central Avenue, Chembur", "1km"));
                mShopList2.add(new shopclass(2, "Swastik Print", "Shop No 12, Opposite Swastik Chambers, C S T Road, Chembur", "1.1km"));
                mShopList2.add(new shopclass(3, "Zoom Cyber Cafe", "Shop No 10, Chembur colony", "1.5km"));
                mShopList2.add(new shopclass(4, "Gemini Enterprise", "Shop No 6 Prakash Building Opp Ornament Hotel Near Chembur Station", "1.8km"));
                mShopList2.add(new shopclass(5, "Print House", "Shop no 6A,Safi Estate,Near munjal Nagar Gate,Amar mahal chembur", "2km"));
                mShopList2.add(new shopclass(6, "HP Printer", "Chembur Station", "2.2km"));
                mShopList2.add(new shopclass(7, "Chembur Print", "Chembur Camp", "2.4km"));
                mShopList2.add(new shopclass(8, "Xerox and Print", "Collectors Colony, Chembur", "2.7km"));
                mShopList2.add(new shopclass(9, "Print and Scan", "Sindhi Society, Chembur", "2.9km"));

                adapter2 = new ShopListAdapter(getApplicationContext(), mShopList2);
                lvShops2.setAdapter(adapter2);

                lvShops2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        Intent intent = new Intent(getApplicationContext(), ShopDetails2.class);
                        startActivity(intent);
                    }
                });


            }

        }
