package com.simran.printease;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListOfShops extends AppCompatActivity {


    private ListView lvShops;
    private ShopListAdapter adapter;
    private List<shopclass> mShopList;
    FloatingActionButton fabcreatejob1;
    private final static String Server_url = "https://printease.000webhostapp.com/shop_list.php";
    GPSTracker gps;
    String latitude;
    String longitude;
    List<shopclass> shop_list_array = new ArrayList<shopclass>();
    String selectedService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_shops);

        Intent i = getIntent();
        Bundle b = i.getExtras();
        selectedService = (String) b.get("selectedService");


        getLocation();
        lvShops = (ListView) findViewById(R.id.lvShops);
        mShopList = new ArrayList<>();
        makeJsonObject();

//        mShopList.add(new shopclass(1, "Royal Print House", "21-22, Navketan Building, Central Avenue Road, Central Avenue, Chembur", "1km"));
//        mShopList.add(new shopclass(2, "Swastik Print", "Shop No 12, Opposite Swastik Chambers, C S T Road, Chembur", "1.1km"));
//        mShopList.add(new shopclass(3, "Zoom Cyber Cafe", "Shop No 10, Chembur colony", "1.5km"));
//        mShopList.add(new shopclass(4, "Gemini Enterprise", "Shop No 6 Prakash Building Opp Ornament Hotel Near Chembur Station", "1.8km"));
//        mShopList.add(new shopclass(5, "Print House", "Shop no 6A,Safi Estate,Near munjal Nagar Gate,Amar mahal chembur", "2km"));
//        mShopList.add(new shopclass(6, "HP Printer", "Chembur Station", "2.2km"));
//        mShopList.add(new shopclass(7, "Chembur Print", "Chembur Camp", "2.4km"));
//        mShopList.add(new shopclass(8, "Xerox and Print", "Collectors Colony, Chembur", "2.7km"));
//        mShopList.add(new shopclass(9, "Print and Scan", "Sindhi Society, Chembur", "2.9km"));
    }

    /** calculates the distance between two locations in MILES */
    private double distance(double lat1, double lng1, double lat2, double lng2) {

        double earthRadius = 3958.75; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        double dist = earthRadius * c;
        DecimalFormat precision = new DecimalFormat("0.00");

        return Double.valueOf(precision.format(dist));// output distance, in MILES
    }
    public void getLocation(){
        gps = new GPSTracker(ListOfShops.this);
        if(gps.canGetLocation()){
            while(gps.getLatitude() == 0.0 && gps.getLongitude() == 0.0){
                //loading spinner
            }
            latitude = String.valueOf(gps.getLatitude());
            longitude = String.valueOf(gps.getLongitude());
            Toast.makeText(getApplicationContext(), "Your Location is - \nLat: "+ latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();

        }else{
            gps.showSettingsAlert();
        }
    }

    public void makeJsonObject() {


        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest strRequest = new StringRequest(Request.Method.POST, Server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(ListOfShops.this,response,Toast.LENGTH_LONG).show();
                            Log.d("suru",response.toString());
                            //JSONObject jsonObject = new JSONObject(response);
                            JSONArray  jsonarray = new JSONArray(response);

                            for (int i = 0; i < jsonarray.length(); i++) {
                                JSONObject jsonobject = jsonarray.getJSONObject(i);
                                int s_id = jsonobject.getInt("s_id");
                                String s_name = jsonobject.getString("s_name");
                                String s_address = jsonobject.getString("s_address");
//                                String url = jsonobject.getString("url");
                                String dis = String.valueOf(distance(Double.valueOf(latitude),Double.valueOf(longitude),Double.valueOf(jsonobject.getString("latitude")),Double.valueOf(jsonobject.getString("longitude"))));
                                shop_list_array.add(new shopclass(s_id, s_name, s_address, dis));
                            }
                            Collections.sort(shop_list_array, new Comparator<shopclass>() {
                                @Override
                                public int compare(shopclass item, shopclass item2) {
                                    double t1 = Double.valueOf(item.getMindist());
                                    double t2 = Double.valueOf(item2.getMindist());

                                    if (t1 > t2){
                                        return 1;
                                    }
                                    if (t1 < t2){
                                        return -1;
                                    }
                                    else{
                                        return 0;
                                    }
                                }

                            });
                            mShopList = shop_list_array;
                            adapter = new ShopListAdapter(getApplicationContext(), mShopList);
                            lvShops.setAdapter(adapter);

                            lvShops.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                                    Intent intent = new Intent(ListOfShops.this, ShopDetails.class);
                                    int Idi = (int) id;
                                    shopclass tobj = shop_list_array.get(Idi);
                                    String idInString = String.valueOf(tobj.getId());
                                    intent.putExtra("s_Id",idInString);
                                    //Toast.makeText(this,"s_Id:"+tobj.getId(),Toast.LENGTH_LONG).show();
                                    intent.putExtra("s_address",tobj.getAddress());
                                    intent.putExtra("s_Name",tobj.getName());
                                    intent.putExtra("s_mindList",tobj.getMindist());
                                    intent.putExtra("lat",latitude);
                                    intent.putExtra("long",longitude);




//                                    Toast.makeText(ListOfShops.this,String.valueOf(id),Toast.LENGTH_LONG).show();
                                    startActivity(intent);
                                }
                            });
                            fabcreatejob1 = (FloatingActionButton) findViewById(R.id.fabcreatejob1);

                            fabcreatejob1.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    Intent intent = new Intent(getApplicationContext(), UploadDetails.class);
                                    startActivity(intent);
                                }
                            });
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        // Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("selectedService",selectedService);
                return params;
            }
        };
        queue.add(strRequest);
    }

}


